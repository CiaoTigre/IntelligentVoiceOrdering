make clean;make build
export LD_LIBRARY_PATH=$(pwd)/../../libs/x86/
