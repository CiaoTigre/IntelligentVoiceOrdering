
#include <iostream>

#include "AIUITest.h"

using namespace std;
using namespace aiui;


int main()
{
	AIUITester t;
	t.test();
	return 0;
}
